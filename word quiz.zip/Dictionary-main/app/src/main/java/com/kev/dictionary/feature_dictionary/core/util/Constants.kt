package com.kev.dictionary.feature_dictionary.core.util

object Constants {
    const val BASE_URL = "https://api.dictionaryapi.dev"
}