package com.kev.dictionary

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DictionaryApp: Application() {
}